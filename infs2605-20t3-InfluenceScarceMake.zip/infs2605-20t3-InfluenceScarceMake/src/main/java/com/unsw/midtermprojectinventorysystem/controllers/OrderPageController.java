package com.unsw.midtermprojectinventorysystem.controllers;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import com.unsw.midtermprojectinventorysystem.App;
import com.unsw.midtermprojectinventorysystem.heplers.DatabaseManager;
import com.unsw.midtermprojectinventorysystem.models.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.text.SimpleDateFormat;

public class OrderPageController {
    @FXML
    TableView<Order> orderView;

    @FXML
    TextField orderId;

    @FXML
    TextField orderTimestamp;

    @FXML
    TextField status;

    @FXML
    TableColumn<Order, String> colOrderTimestamp;

    @FXML
    TableColumn<Order, String> colStatus;

    @FXML
    TableView<OrderProduct> addProductView;

    @FXML
    ChoiceBox<String> cbOfProduct;

    @FXML
    ChoiceBox<String> cbOfSupplier;

    @FXML
    TextField addQuantity;

    Alert alertBox = new Alert(Alert.AlertType.WARNING);


    @FXML
    public void initialize() throws SQLException {
        colOrderTimestamp.setCellValueFactory(new PropertyValueFactory<>("orderTimestamp"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        colOrderTimestamp.setCellFactory(TextFieldTableCell.forTableColumn());
        colStatus.setCellFactory(TextFieldTableCell.forTableColumn());
        orderView.setEditable(true);

        colOrderTimestamp.setOnEditCommit(e->{
            e.getTableView().getItems().get(e.getTablePosition().getRow()).setOrderTimestamp(e.getNewValue());
            Order order = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try {
                DatabaseManager.updateOrder(order);
            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });
        colStatus.setOnEditCommit(e->{
            Order order = e.getTableView().getItems().get(e.getTablePosition().getRow());
            try {
                int supplierId = DatabaseManager.fetchSupplierIdByUser(App.loginUser);
                ArrayList<OrderProduct> products = DatabaseManager.fetchProductsByOrder(order.getOrderId());
                boolean isChanged = false;
                for (OrderProduct product : products){
                    if (product.getSupplierId() == supplierId){
                        isChanged = true;
                        break;
                    }
                }
                if (isChanged){
                    e.getTableView().getItems().get(e.getTablePosition().getRow()).setStatus(e.getNewValue());
                    DatabaseManager.updateOrder(order);
                } else{
                    e.getTableView().getItems().get(e.getTablePosition().getRow()).setStatus(e.getOldValue());
                    orderView.refresh();
                    alertBox.setContentText("You are not the employee, cannot update the order status");
                    alertBox.show();
                }

            } catch (SQLException exception) {
                exception.printStackTrace();
            }
        });

        ObservableList<Order> data = orderView.getItems();
        ArrayList<Order> orders = DatabaseManager.fetchAllOrders();
        data.addAll(orders);
        orderView.setItems(data);

        initializeChoiceBox();
    }

    private void initializeChoiceBox() throws SQLException {
        ArrayList<Product> products = DatabaseManager.fetchAllProducts();
        cbOfProduct.getItems().clear();
        for (Product product : products){
            cbOfProduct.getItems().add(product.getProductId() + "|" + product.getProductName());
        }

        ArrayList<Supplier> suppliers = DatabaseManager.fetchAllSuppliers();
        cbOfSupplier.getItems().clear();
        for (Supplier supplier : suppliers){
            cbOfSupplier.getItems().add(supplier.getSupplierId() + "|" + supplier.getSupplierName());
        }
    }

    @FXML
    public void addOrder() throws SQLException {
        String addOrderId = orderId.getText();
        String addOrderStatus = status.getText();
        if(addOrderStatus == ""){
            addOrderStatus = "OrderPlaced";
        }
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String addOrderTimestamp = formatter.format(new Date());
        Order order = new Order(Integer.parseInt(addOrderId), addOrderTimestamp, addOrderStatus);
        DatabaseManager.addOrder(order);
        // update supplier list view
        ObservableList<Order> data = orderView.getItems();
        data.add(order);
        orderView.setItems(data);

        // clean text fields
        orderId.clear();
        status.clear();
    }

    @FXML
    public void deleteOrder() throws SQLException {
        Order order = orderView.getItems().get(orderView.getSelectionModel().getSelectedIndex());
        DatabaseManager.deleteOrder(order);
        ObservableList<Order> data = orderView.getItems();
        data.remove(order);
    }

    @FXML
    public void addProduct() throws SQLException {
        String selProduct = cbOfProduct.getValue();
        String selSupplier = cbOfSupplier.getValue();
        int productId = Integer.parseInt(selProduct.split("|")[0]);
        int supplierId = Integer.parseInt(selSupplier.split("|")[0]);
        int quantity = Integer.parseInt(addQuantity.getText());
        int orderId = orderView.getItems().get(orderView.getSelectionModel().getSelectedIndex()).getOrderId();
        OrderProduct orderProduct = new OrderProduct(orderId, productId, supplierId, quantity);
        DatabaseManager.addOrderProduct(orderProduct);

        addProductView.getItems().add(orderProduct);
    }

    @FXML
    public void onOrderViewRowClicked() throws SQLException {
        Order order = orderView.getItems().get(orderView.getSelectionModel().getSelectedIndex());
        ObservableList<OrderProduct> products = addProductView.getItems();
        products.clear();
        ArrayList<OrderProduct> data = DatabaseManager.fetchProductsByOrder(order.getOrderId());
        products.addAll(data);
    }
}
