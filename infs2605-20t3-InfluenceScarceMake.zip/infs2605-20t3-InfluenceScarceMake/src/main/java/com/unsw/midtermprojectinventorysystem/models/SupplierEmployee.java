package com.unsw.midtermprojectinventorysystem.models;

public class SupplierEmployee {

    private int supplierId;

    private int employeeId;

    public SupplierEmployee(){

    }

    public SupplierEmployee(int supplierId, int employeeId){
        this.supplierId = supplierId;
        this.employeeId = employeeId;
    }

    public void setSupplierId(int supplierId){
        this.supplierId = supplierId;
    }

    public void setEmployeeId(int employeeId){
        this.employeeId = employeeId;
    }

    public int getSupplierId(){
        return this.supplierId;
    }

    public int getEmployeeId(){
        return this.employeeId;
    }
}
