package com.unsw.midtermprojectinventorysystem.models;

public class Supplier {

    private String supplierId;

    private String supplierName;

    private String phoneNumber;

    private String address;

    public Supplier(){

    }

    public Supplier(String supplierId, String supplierName, String phoneNumber, String address){
        this.supplierId = supplierId;
        this.supplierName = supplierName;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    public void setSupplierId(String supplierId){
        this.supplierId = supplierId;
    }

    public void setSupplierName(String supplierName){
        this.supplierName = supplierName;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setAddress(String address){
        this.address = address;
    }

    public String getSupplierId(){
        return this.supplierId;
    }

    public String getSupplierName(){
        return this.supplierName;
    }

    public String getPhoneNumber(){
        return this.phoneNumber;
    }

    public String getAddress(){
        return this.address;
    }
}
