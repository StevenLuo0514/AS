package com.unsw.midtermprojectinventorysystem.models;

public class Order {

    private Integer orderId;

    private String orderTimestamp;

    private String status;

    public Order(Integer orderId, String orderTimestamp, String status){
        this.orderId = orderId;
        this.orderTimestamp = orderTimestamp;
        this.status = status;
    }

    public void setOrderId(Integer orderId){
        this.orderId = orderId;
    }

    public void setOrderTimestamp(String orderTimestamp){
        this.orderTimestamp = orderTimestamp;
    }

    public void setStatus(String status){
        this.status = status;
    }

    public Integer getOrderId(){
        return this.orderId;
    }

    public String getOrderTimestamp(){
        return this.orderTimestamp;
    }

    public String getStatus(){
        return this.status;
    }
}
