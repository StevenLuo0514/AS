package com.unsw.midtermprojectinventorysystem.heplers;

import com.unsw.midtermprojectinventorysystem.models.*;

import java.sql.*;
import org.mindrot.jbcrypt.BCrypt;
import java.util.ArrayList;

public class DatabaseManager {

    public static boolean checkPwd(String userName, String pwd) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT password FROM User WHERE username = ?";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, userName);
        ResultSet rs = st.executeQuery();
        String realPassword = "";
        while(rs.next()){
            realPassword = rs.getString("password");
        }
        st.close();
        conn.close();
        return BCrypt.checkpw(pwd, realPassword);
    }

    public static ArrayList<Order> fetchAllOrders() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT * FROM `Order` ORDER BY order_id";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);
        ArrayList<Order> orders = new ArrayList<>();
        while(rs.next()){
            orders.add(new Order(rs.getInt("order_id"),
                    rs.getString("order_timestamp"),
                    rs.getString("status")));
        }
        st.close();
        conn.close();
        return orders;
    }

    public static ArrayList<OrderProduct> fetchProductsByOrder(int orderId) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT * FROM OrderProduct WHERE order_id = ?";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, orderId);
        ResultSet rs = st.executeQuery();
        ArrayList<OrderProduct> products = new ArrayList<OrderProduct>();
        while(rs.next()){
            products.add(new OrderProduct(orderId, rs.getInt("product_id"),
                    rs.getInt("supplier_id"), rs.getInt("quantity")));
        }
        st.close();
        conn.close();
        return products;
    }

    public static ArrayList<OrderStatusUpdate> fetchOrderStatusByOrder(int orderId) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT * FROM OrderStatusUpdate WHERE order_id = ? ORDER BY update_timestamp DESC";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, orderId);
        ResultSet rs = st.executeQuery();
        ArrayList<OrderStatusUpdate> status = new ArrayList<OrderStatusUpdate>();
        while(rs.next()){
            status.add(new OrderStatusUpdate(rs.getInt("update_id"), rs.getInt("order_id"),
                    rs.getString("status"), rs.getString("update_timestamp"),
                    rs.getInt("update_user")));
        }
        st.close();
        conn.close();
        return status;
    }

    public static Product fetchProductInfo(int productId) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT * FROM Product WHERE product_id = ? ";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, productId);
        ResultSet rs = st.executeQuery();
        Product product = new Product();
        while(rs.next()){
            product.setProductId(rs.getInt("product_id"));
            product.setProductName(rs.getString("product_name"));
            product.setProductType(rs.getString("product_type"));
            product.setPrice(rs.getFloat("price"));
        }
        st.close();
        conn.close();
        return product;
    }

    public static Store fetchStoreInfo(int storeId) throws SQLException {

        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT * FROM Store WHERE store_id = ? ";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, storeId);
        ResultSet rs = st.executeQuery();
        Store store = new Store();
        while(rs.next()){
            store.setStoreId(rs.getInt("store_id"));
            store.setAddress(rs.getString("address"));
            store.setPhoneNumber(rs.getString("phone_number"));
            store.setStoreManager(rs.getInt("store_manager"));

        }
        st.close();
        conn.close();
        return store;

    }

    public static Supplier fetchSupplierInfo(int supplierId) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT * FROM Supplier WHERE supplier_id = ? ";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, supplierId);
        ResultSet rs = st.executeQuery();
        Supplier supplier = new Supplier();
        while(rs.next()){
            supplier.setSupplierId(rs.getString("supplier_id"));
            supplier.setPhoneNumber(rs.getString("phone_number"));
            supplier.setAddress(rs.getString("address"));
            supplier.setSupplierName(rs.getString("supplier_name"));

        }
        st.close();
        conn.close();
        return supplier;
    }

    public static ArrayList<Supplier> fetchAllSuppliers() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT * FROM Supplier ORDER BY supplier_id";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);
        ArrayList<Supplier> suppliers = new ArrayList<>();
        while(rs.next()){
            suppliers.add(new Supplier(rs.getString("supplier_id"), rs.getString("supplier_name"),
                    rs.getString("phone_number"), rs.getString("address")));
        }
        st.close();
        conn.close();
        return suppliers;

    }

    public static ArrayList<Product> fetchAllProducts() throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT * FROM Product ORDER BY product_id";
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sql);
        ArrayList<Product> products = new ArrayList<>();
        while(rs.next()){
            products.add(new Product(rs.getInt("product_id"), rs.getString("product_name"),
                    rs.getFloat("price"), rs.getString("product_type")));
        }
        st.close();
        conn.close();
        return products;
    }

    public static void addSupplier(Supplier supplier) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "INSERT INTO Supplier(supplier_id, supplier_name, phone_number, address) VALUES(?, ?, ?, ?)";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, Integer.parseInt(supplier.getSupplierId()));
        st.setString(2, supplier.getSupplierName());
        st.setString(3, supplier.getPhoneNumber());
        st.setString(4, supplier.getAddress());
        st.execute();
        st.close();
        conn.close();

    }

    public static void addOrder(Order order) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "INSERT INTO `Order`(order_id, order_timestamp, status) VALUES(?, ?, ?)";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, order.getOrderId());
        st.setString(2, order.getOrderTimestamp());
        st.setString(3, order.getStatus());
        st.execute();
        st.close();
        conn.close();
    }

    public static void updateSupplier(Supplier supplier) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "UPDATE Supplier SET supplier_name = ?, phone_number = ?, address = ? WHERE supplier_id = ?";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, supplier.getSupplierName());
        st.setString(2, supplier.getPhoneNumber());
        st.setString(3, supplier.getAddress());
        st.setInt(4, Integer.parseInt(supplier.getSupplierId()));
        st.execute();
        st.close();
        conn.close();
    }

    public static void updateOrder(Order order) throws SQLException{
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "UPDATE `Order` SET order_timestamp = ?, status = ? WHERE order_id = ?";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, order.getOrderTimestamp());
        st.setString(2, order.getStatus());
        st.setInt(3, order.getOrderId());
        st.execute();
        st.close();
        conn.close();
    }

    public static void deleteOrder(Order order) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "DELETE FROM `Order` WHERE order_id = ?";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, order.getOrderId());
        st.execute();
        st.close();
        conn.close();
    }

    public static void addOrderProduct(OrderProduct orderProduct) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "INSERT INTO OrderProduct(order_id, product_id, supplier_id, quantity) VALUES(?, ?, ?, ?)";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setInt(1, orderProduct.getOrderId());
        st.setInt(2, orderProduct.getProductId());
        st.setInt(3, orderProduct.getSupplierId());
        st.setInt(4, orderProduct.getQuantity());
        st.execute();
        st.close();
        conn.close();
    }

    public static int fetchSupplierIdByUser(String userName) throws SQLException {
        Connection conn = DriverManager.getConnection("jdbc:sqlite:inventory.db");
        String sql = "SELECT supplier_id FROM SupplierEmployee WHERE employee_id = " +
                "(SELECT user_id FROM User WHERE username = ?)";
        PreparedStatement st = conn.prepareStatement(sql);
        st.setString(1, userName);
        ResultSet rs = st.executeQuery();
        int supplierId = -1;
        while(rs.next()){
            supplierId = rs.getInt("supplier_id");
        }
        return supplierId;
    }

}
