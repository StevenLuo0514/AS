package com.unsw.midtermprojectinventorysystem.controllers;

import java.io.IOException;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import com.unsw.midtermprojectinventorysystem.heplers.DatabaseManager;
import com.unsw.midtermprojectinventorysystem.App;

public class LoginScreenController {

    @FXML
    TextField userName;

    @FXML
    TextField password;

    @FXML
    Label errorInfo;

    @FXML
    private void handleLoginButtonAction(ActionEvent event) throws IOException, SQLException {
        String userInput = userName.getText();
        String passwordInput = password.getText();
        if(DatabaseManager.checkPwd(userInput, passwordInput)){
            errorInfo.setText("");
            App.loginUser = userInput;
            App.setRoot("home");
        }else{
            errorInfo.setText("Sorry, incorrect credentials.");
        }
    }
}
