package com.unsw.midtermprojectinventorysystem.models;

public class OrderProduct {

    private Integer orderId;

    private Integer productId;

    private Integer supplierId;

    private Integer quantity;

    public OrderProduct(Integer orderId, Integer productId, Integer supplierId, Integer quantity){
        this.orderId = orderId;
        this.productId = productId;
        this.supplierId = supplierId;
        this.quantity = quantity;
    }

    public void setOrderId(int orderId){
        this.orderId = orderId;
    }

    public void setProductId(int productId){
        this.productId = productId;
    }

    public void setSupplierId(int supplierId){
        this.supplierId = supplierId;
    }

    public void setQuantity(int quantity){
        this.quantity = quantity;
    }

    public int getOrderId(){
        return this.orderId;
    }

    public int getProductId(){
        return this.productId;
    }

    public int getSupplierId(){
        return this.supplierId;
    }

    public int getQuantity(){
        return this.quantity;
    }
}
