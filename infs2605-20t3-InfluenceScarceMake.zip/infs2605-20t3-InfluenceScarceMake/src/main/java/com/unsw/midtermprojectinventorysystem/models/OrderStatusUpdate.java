package com.unsw.midtermprojectinventorysystem.models;

public class OrderStatusUpdate {

    private int updateId;

    private int orderId;

    private String status;

    private String updateTimestamp;

    private int updateUser;

    public OrderStatusUpdate(int updateId, int orderId, String status, String updateTimestamp, int updateUser) {
        this.updateId = updateId;
        this.orderId = orderId;
        this.status = status;
        this.updateTimestamp = updateTimestamp;
        this.updateUser = updateUser;
    }

    public void setUpdateId(int updateId){
        this.updateId = updateId;
    }

    public void setOrderId(int orderId){
        this.orderId = orderId;
    }

    public void setStatus(String status){
        this.status = status;
    }

    public void setUpdateTimestamp(String updateTimestamp){
        this.updateTimestamp = updateTimestamp;
    }

    public void setUpdateUser(int updateUser){
        this.updateUser = updateUser;
    }

    public int getUpdateId(){
        return this.updateId;
    }

    public int getOrderId(){
        return this.orderId;
    }

    public String getStatus(){
        return this.status;
    }

    public String getUpdateTimestamp(){
        return this.updateTimestamp;
    }

    public int getUpdateUser(){
        return this.updateUser;
    }
}
