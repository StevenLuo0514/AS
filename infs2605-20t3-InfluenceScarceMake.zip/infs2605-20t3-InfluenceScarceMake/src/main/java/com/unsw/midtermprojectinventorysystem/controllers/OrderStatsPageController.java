package com.unsw.midtermprojectinventorysystem.controllers;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import com.unsw.midtermprojectinventorysystem.heplers.DatabaseManager;
import com.unsw.midtermprojectinventorysystem.models.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class OrderStatsPageController {
    @FXML
    PieChart pieChart;

    @FXML
    TextField searchField;

    @FXML
    TableView<Order> orderView;

    @FXML
    public void initialize() throws SQLException {
        ArrayList<Order> orders = DatabaseManager.fetchAllOrders();
        HashMap<String, Integer> countsMap = new HashMap<>();
        for(Order order : orders){
            if (!countsMap.containsKey(order.getStatus())){
                countsMap.put(order.getStatus(), 0);
            }
            countsMap.replace(order.getStatus(), countsMap.get(order.getStatus()) + 1);
        }
        ObservableList<PieChart.Data> pieData = FXCollections.observableArrayList();
        if (!orders.isEmpty()){
            for (String key : countsMap.keySet()){
                pieData.add(new PieChart.Data(key, (double) countsMap.get(key) / orders.size()));
            }
        }
        pieChart.setData(pieData);

        orderView.getItems().clear();
        orderView.getItems().addAll(orders);
    }

    @FXML
    public void onSearch() throws SQLException{
        String searchStr = searchField.getText();
        if (searchStr.length() == 0){
            ArrayList<Order> orders = DatabaseManager.fetchAllOrders();
            orderView.getItems().clear();
            orderView.getItems().addAll(orders);
        } else{
            ArrayList<Product> products = DatabaseManager.fetchAllProducts();
            HashMap<Integer, String> productMap = new HashMap<>();
            for (Product product : products){
                productMap.put(product.getProductId(), product.getProductName());
            }
            ObservableList<Order> orders = FXCollections.observableArrayList();
            for(Order order : orderView.getItems()){
                ArrayList<OrderProduct> items = DatabaseManager.fetchProductsByOrder(order.getOrderId());
                StringBuilder productInfo = new StringBuilder();
                for (OrderProduct item : items){
                    productInfo.append(productMap.get(item.getProductId()));
                }
                if(order.getStatus().contains(searchStr) || productInfo.toString().contains(searchStr)){
                    orders.add(order);
                }
            }
            orderView.getItems().clear();
            orderView.getItems().addAll(orders);
        }
    }

}
