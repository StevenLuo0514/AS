module com.unsw.midtermprojectinventorysystem {
    requires javafx.baseEmpty;
    requires javafx.base;
    requires javafx.controlsEmpty;
    requires javafx.controls;
    requires javafx.graphicsEmpty;
    requires javafx.graphics;
    requires javafx.fxmlEmpty;
    requires javafx.fxml;
    
    requires java.sql;
    requires jbcrypt;

    opens com.unsw.midtermprojectinventorysystem.controllers to javafx.fxml;
    opens com.unsw.midtermprojectinventorysystem.models to javafx.base;
    exports com.unsw.midtermprojectinventorysystem;
}
